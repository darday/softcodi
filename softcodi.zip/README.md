para que el proyecto funcione deben hacer lo siguiente:
--despues de clonar el proyecto abrir la terminal dentro del proyecto
1.- ejecutamos el comando : composer install
2.- creamos el archivo .env (Duplicamos el .env.example y lo renombramos por .env)
3.- php artisan key:generate
4.- de esta forma se podrá ejecutar el proyecto caso contrario dará errores


5.-En el archivo .env se trabajara con la base de datos softcodi
6.- Antes de Subir cualquier Cambio verificar que esta en su rama correspondiente


