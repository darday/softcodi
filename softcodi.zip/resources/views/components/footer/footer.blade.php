
 <footer class="page-footer font-small mdb-color pt-4 bg-dark">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">
  
      <!-- Footer links -->
      <div class="row text-center text-md-left ">
  
        <!-- Grid column 
        <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
          <h6 class="text-uppercase mb-4 font-weight-bold">Company name</h6>
          <p>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
            consectetur
            adipisicing elit.</p>
        </div>-->
        
        <div class="col-md-12 col-lg-12 col-xl-12 col-xl-12 " style="color:white">
          <h6 class="text-uppercase mb-4 font-weight-bold" >Contacto</h6>        
        </div>
        
          <div class=" col-md-6 col-lg-6  col-xl-6 " style="color:white">       
              <i class="fa fa-map-marker" style="color:white"></i>   Departamento Desarrollo: 0961119670<br>        
              <i class="fa fa-envelope"  style="color:white"></i> Departamento Mantenimiento: 0984111628<br>       
          </div>
          <div class=" col-md-4 col-lg-6 col-xl-6 col-xl-6 " style="color:white">
                      
              <i class="fa fa-phone"  style="color:white"></i> Departamento Contabilidad: 0993786135<br>       
              <i class="fa fa-phone"  style="color:white"></i> Departamento Diseño: 0961119670
          </div>
  
        <!-- Grid column -->
  
      </div>
      <!-- Footer links -->
  
      <hr>
  
      <!-- Grid row -->
      <div class="row d-flex align-items-center" style="color:white">
  
        <!-- Grid column -->
        <div class="col-md-6 col-lg-6">
  
          <!--Copyright-->
          <p class="text-center text-md-left" style="color:white">©
               <a > Diseño Web: SOFTCODI.Cia.Ltda</a>
          </p>
  
        </div>
        <!-- Grid column -->
  
        <!-- Grid column -->
        <div class="col-md-6 col-lg-6 ml-lg-0">
  
          <!-- Social buttons -->
          <div class="text-center text-md-right">
            <ul class="list-unstyled list-inline">
              <li class="list-inline-item">
                  <a target="blanck" href="https://www.facebook.com/SoftcodiCiaLtda-100164048985381/">
                      <i class="fab fa-facebook-square" style="font-size:30px;color:white"></i>                      
                  </a>
              </li>
             
              <li class="list-inline-item">
                  <a  target="blanck" href="https://api.whatsapp.com/send?phone=+593961119670&text=Hola! podrían ayudarme?">
                      <i class="fab fa-whatsapp" style="font-size:30px;color:white"></i>
                  </a>
              </li>
             
              {{-- <li class="list-inline-item">
                  <a  target="blanck" href="https://www.instagram.com/artenativofundacion/?hl=es-la">
                      <i class="fab fa-linkedin" style="font-size:30px;color:white"></i>
                  </a>
              </li> --}}
            
            </ul>
          </div>
  
        </div>
        <!-- Grid column -->
  
      </div>
      <!-- Grid row -->
  
    </div>
    <!-- Footer Links -->
  
  </footer>