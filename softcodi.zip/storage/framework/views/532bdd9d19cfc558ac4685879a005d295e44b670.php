
<div class="cont_img" >  
  <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner" role="listbox">
      <div class="carousel-item active" data-bs-interval="4000"  style="background-image: url('assets/img/carousel/desarrollo.jpg') ;  ">
        <div style="background-color:rgba(43, 39, 39, 0.397) ; width:100%; height:100vh" >
          <div class="text_cent_img animated zoomIn"><h1 class="tit-sob-img" >DESARROLLO DE PÁGINAS WEB Y APLICACIONES MÓVILES <br>PARA TU EMPRESA</h1></div>
          <div class="text_cent_img2 animated zoomIn"><p class="tit-sob-img2" style="color: white">Soluciones Empresariales</p></div>
        </div>
              
      </div>

      <div class="carousel-item" data-bs-interval="4000" style="background-image: url('assets/img/carousel/contabilidad.jpg') ">
        <div style=" width:100%; height:100vh; background-color:rgba(43, 39, 39, 0.397)" >
          <div class="text_cent_img animated zoomIn" style=""><h1 class="tit-sob-img" >SISTEMAS DE INVENTARIO Y<br>ASESORÍA CONTABLE PARA TU EMPRESA</h1></div>
          <div class="text_cent_img2 animated zoomIn"><p class="tit-sob-img2" style="color: white">Soluciones Empresariales</p></div>
        </div>
      </div>
      <div class="carousel-item"  data-bs-interval="4000" style="background-image: url('assets/img/carousel/disenio.jpg') ">
        
        <div style=" width:100%; height:100vh" >
          <div style=" width:100%; height:100vh; background-color:rgba(43, 39, 39, 0.397)" >
            <div class="text_cent_img animated zoomIn" style=""><h1 class="tit-sob-img" >DISEÑO DE MARCA Y <br>MARKETING DIGITAL PARA TU EMPRESA</h1></div>
            <div class="text_cent_img2 animated zoomIn"><p class="tit-sob-img2" style="color: white">Soluciones Empresariales</p></div>
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>

<?php /**PATH C:\xampp\htdocs\Softcodi_Developer\softcodi\resources\views/components/carousel/carousel.blade.php ENDPATH**/ ?>