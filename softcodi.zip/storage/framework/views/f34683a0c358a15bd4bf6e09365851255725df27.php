<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <img src="../assets/img/logos/softcodi_letras.png"  alt="" width="auto" height="55vh">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Inicio</a>
            </li>
            
            

            <li class="nav-item">
                <a class="nav-link"  href="<?php echo e(url('/contabilidad')); ?>">Contabilidad</a>
            </li>

            <li class="nav-item">
                <a class="nav-link"  href="<?php echo e(url('/desarrollo-web')); ?>">Desarrollo web y móvil</a>
            </li>


            <!--  -->


            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Soporte Técnico
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <li><a class="dropdown-item" href="<?php echo e(url('/mantenimiento-pcs')); ?>">Mantenimiento de PC's</a></li>
                <li><a class="dropdown-item" href="<?php echo e(url('/ventas-repuestos')); ?>">Venta de Repuestos</a></li>
            </ul>
            </li>

           

            <a class="nav-link" href="<?php echo e(url('/diseño-grafico')); ?>">Diseño Gráfico</a>
        </li>
        <li class="nav-item">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/equipo-de-trabajo')); ?>">Nuestro Equipo</a>
            </li>
        </ul>
    </div>

  </div>
</nav><?php /**PATH C:\xampp\htdocs\Softcodi Developer\softcodi\resources\views/components/navbar/navbar.blade.php ENDPATH**/ ?>